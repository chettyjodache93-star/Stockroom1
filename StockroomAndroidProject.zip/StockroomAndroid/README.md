# Stockroom Android app

This is an Android Studio project that wraps the Stockroom inventory page in a native Android WebView. It requests camera permission for barcode scanning and serves the page from Android's secure WebView asset origin.

## Build an APK

1. Install **Android Studio** and its Android SDK (API 35).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show a link to the generated debug APK. It is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it. If Android asks, allow installation from the app you used to open the APK.

For a shareable release build, use **Build → Generate Signed Bundle / APK… → APK** and create a signing key.

## Notes

- The scanner uses the `html5-qrcode` CDN, so the first launch and scanning require an internet connection.
- Camera access requires granting the Android camera permission.
- Inventory is stored in this app's WebView local storage on that device. Clearing app data or uninstalling the app removes that local inventory. Export/backup is not currently included.
