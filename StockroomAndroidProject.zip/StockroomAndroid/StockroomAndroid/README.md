# Stockroom Android app

This is an Android Studio project that wraps the Stockroom inventory page in a native Android WebView. It requests camera permission for barcode scanning and serves the page from Android's secure WebView asset origin.

## Build an APK

1. Install **Android Studio** and its Android SDK (API 35).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show a link to the generated debug APK. It is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it. If Android asks, allow installation from the app you used to open the APK.

For a shareable release build, use **Build → Generate Signed Bundle / APK… → APK** and create a signing key.

## Notes

- **Machine Downtime layout:** four fold-out sections stacked one under another — *Live* (record stoppages, machine status), *Reports* (Daily report and Weekly report, each also fold-out), *History*, and *Setup* (rename/delete machines, downtime reasons, reorder email). Tap a section to open it, tap again to close. The app remembers which section was open.
- **Machines without scanning:** add a machine under Downtime → Setup (name, optional barcode/ID; blank creates an ID like M-0001). Stop a running machine with its **Stop** button under Live — it uses the day and reason selected above.
- **Weekly report:** in Machine Downtime → Reports → Weekly report, upload at least 3 daily report PDFs (made with *Download PDF* on the daily report; older shift report PDFs also work) or add daily reports saved on the phone, then press *Generate weekly report*. The report covers only the days in those reports and can be downloaded as a PDF. The PDF reader (pdf.js 6.2.108, Apache-2.0) is bundled in `assets/public/pdfjs`, so this works offline.
- The scanner uses the `html5-qrcode` CDN, so the first launch and scanning require an internet connection.
- Camera access requires granting the Android camera permission.
- Inventory is stored in this app's WebView local storage on that device. Clearing app data or uninstalling the app removes that local inventory. Export/backup is not currently included.


## Build compatibility fix
This project uses `android.app.Activity` for the WebView wrapper and sets both Java
and Kotlin compilation targets to JVM 17. Replace the ZIP in the GitHub repository
with this corrected archive before running the GitHub Actions workflow again.

- **Days instead of shifts:** stoppages and reports use Monday–Sunday instead of Day/Night shift. The day picker defaults to today. On first launch after updating, existing Day/Night records are converted to the weekday they happened on, and a date's Day and Night planned times are added together.
- **Daily report target analysis:** set an availability target on the daily report (shared with the weekly report). Stops and machines are listed from highest downtime. If the day missed the target, the report groups downtime by reason, highest first, and keeps adding reasons until fixing them would have hit the target, showing availability after each one.
